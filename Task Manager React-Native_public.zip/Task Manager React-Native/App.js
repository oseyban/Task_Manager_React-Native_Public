import 'react-native-get-random-values';
import React, { useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { FontAwesome5 } from '@expo/vector-icons';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import HomePage from './pages/HomePage';
import AdminPage from './pages/AdminPage';
import TaskPage from './pages/TaskPage';
import NotificationPage from './pages/NotificationPage';
import SigninPage from './pages/SigninPage';
import { TouchableOpacity, View, Text } from 'react-native';
import { firebase } from './pages/firebase';

const Tab = createBottomTabNavigator();

const App = () => {
  // Kullanıcının oturum durumunu tutan state
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  // Çıkış işlemini gerçekleştiren fonksiyon
  const handleLogout = async ({ navigation }) => {
    try {
      const user = firebase.auth().currentUser;
  
      if (user) {
        // Kullanıcı oturum açık ise çıkış yap
        setIsLoggedIn(false);
        await firebase.auth().signOut();
        navigation.navigate('HomePage');
        alert('Çıkış Yapıldı');
      } else {
        // Kullanıcı zaten oturum açık değilse bir işlem yapma
        alert('Zaten oturum açık değil.');
      }
    } catch (error) {
      console.error('Çıkış hatası:', error.message);
    }
  };

  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={{
          headerStyle: {
            backgroundColor: '#00aff0',
            shadowColor: 'rgba(0, 0, 0, 0.4)',
            shadowOffset: {
              width: 0,
              height: 2,
            },
            shadowRadius: 4,
          },
          headerTitleStyle: {
            fontSize: 20,
            fontWeight: 'bold',
            color: '#fff',
          },
        }}>
        {isLoggedIn ? (
          // Oturum açık ise yönetim ve diğer sayfaları göster
          <>
            <Tab.Screen
              name="AdminPage"
              component={AdminPage}
              options={{
                tabBarLabel: 'Yönetim',
                tabBarIcon: ({ color, size }) => (
                  <MaterialCommunityIcons
                    name="clipboard-list-outline"
                    size={24}
                    color="#00aff0"
                  />
                ),
                headerTitle: 'Task Manager Yönetim',
              }}
            />
            <Tab.Screen
              name="TaskPage"
              component={TaskPage}
              options={{
                tabBarLabel: 'Görevler',
                tabBarIcon: ({ color, size }) => (
                  <FontAwesome5 name="tasks" size={24} color="#00aff0" />
                ),
                headerTitle: 'Task Manager Görevler',
              }}
            />
            <Tab.Screen
              name="NotificationPage"
              component={NotificationPage}
              options={{
                tabBarLabel: 'Duyurular',
                tabBarIcon: ({ color, size }) => (
                  <Ionicons
                    name="notifications-outline"
                    size={24}
                    color="#00aff0"
                  />
                ),
                headerTitle: 'Task Manager Duyurular',
              }}
            />
          </>
        ) : (
          // Oturum açık değil ise giriş ve üyelik sayfalarını göster
          <>
            <Tab.Screen
              name="HomePage"
              component={(props) => <HomePage {...props} setIsLoggedIn={setIsLoggedIn} />}
              options={{
                tabBarLabel: 'Giriş',
                tabBarIcon: ({ color, size }) => (
                  <Ionicons name="home" color={'#00aff0'} size={size} />
                ),
                headerTitle: 'Task Manager Giriş',
              }}
            />
            <Tab.Screen
              name="SigninPage"
              component={SigninPage}
              options={{
                tabBarLabel: 'Üyelik',
                tabBarIcon: ({ color, size }) => (
                  <Ionicons name="log-in" color={'#00aff0'} size={size} />
                ),
                headerTitle: 'Task Manager Üyelik',
              }}
            />
          </>
        )}
        {/* Çıkış butonu */}
        <Tab.Screen
          name="Exit"
          options={{
            tabBarLabel: 'Çıkış',
            tabBarIcon: ({ color, size }) => (
              <Ionicons name="log-out" color={'#00aff0'} size={size} />
            ),
            headerTitle: 'Task Manager Çıkış',
          }}>
          {({ navigation }) => (
            <TouchableOpacity onPress={() => handleLogout({ navigation })}>
              {/* Çıkış butonuna tıklanınca logout fonksiyonunu çağır */}
            </TouchableOpacity>
          )}
        </Tab.Screen>
      </Tab.Navigator>
    </NavigationContainer>
  );
};

export default App;
