
import firebase from 'firebase/compat/app';
import 'firebase/compat/auth';

const firebaseConfig = {
  apiKey: "Your API key",
  authDomain: "Your-Firebase_Domain",
  projectId: "Your Firebase-Projeck-ID",
  storageBucket: "Your Firebase-Bucket",
  messagingSenderId: "Your-Message-Sender ID",
  appId: "Your AppId",
  measurementId: "Your MeasurementID"
};

if(!firebase.apps.length) {
  firebase.initializeApp(firebaseConfig);
}
const auth =firebase.auth();



export {auth,firebase}; 