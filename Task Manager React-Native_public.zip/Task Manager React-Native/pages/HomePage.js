import React, { useState } from 'react';
import { Text, View, TextInput, TouchableOpacity, StyleSheet, Modal } from 'react-native';
import OTPInputView from '@twotalltotems/react-native-otp-input';
import { auth, firebase } from './firebase';

const HomePage = ({ navigation, setIsLoggedIn }) => {
  // State'lerin tanımlanması
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [otp, setOtp] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [isModalVisible, setModalVisible] = useState(false);

  // Kullanıcının e-posta ve şifresiyle giriş yapılmasını sağlayan fonksiyon
  const handleSignIn = async () => {
    try {
      const userCredential = await auth.signInWithEmailAndPassword(email, password);
      const user = userCredential.user;

      if (!user.emailVerified) {
        setErrorMessage('E-posta adresinizi doğrulamadan giriş yapamazsınız.');
        return;
      }

      setModalVisible(true);

    } catch (error) {
      console.error('Giriş hatası:', error.message);
      setErrorMessage('Giriş sırasında bir hata oluştu.');
    }
  };

  // E-posta doğrulama e-postasının tekrar gönderilmesini sağlayan fonksiyon
  const resendVerificationEmail = async () => {
    try {
      const user = auth.currentUser;

      if (user) {
        await user.sendEmailVerification();
        setErrorMessage('E-posta doğrulama e-postası tekrar gönderildi.');
        setModalVisible(true);
      } else {
        setErrorMessage('Kullanıcı bulunamadı.');
      }
    } catch (error) {
      console.error('E-posta doğrulama e-postası gönderme hatası:', error.message);
      setErrorMessage('E-posta doğrulama e-postası gönderme sırasında bir hata oluştu.');
    }
  };

  // OTP kodunun doğrulanması ve kullanıcının yönlendirilmesini sağlayan fonksiyon
  const handleOTPVerification = async () => {
    try {
      const user = auth.currentUser;

      if (user) {
        const credential = firebase.auth.EmailAuthProvider.credential(user.email, otp);
        await user.reauthenticateWithCredential(credential);

        setIsLoggedIn(true);
        navigation.navigate('AdminPage');
      } else {
        setErrorMessage('Kullanıcı bulunamadı.');
      }
    } catch (error) {
      console.error('OTP doğrulama hatası:', error.message);
      setErrorMessage('OTP doğrulama sırasında bir hata oluştu.');
    }
  };

  return (
    <View style={styles.container}>
      {/* E-posta ve şifre giriş alanları */}
      <TextInput
        style={styles.input}
        placeholder="E-posta Adresi"
        value={email}
        onChangeText={setEmail}
      />
      <TextInput
        style={styles.input}
        placeholder="Şifre"
        secureTextEntry
        value={password}
        onChangeText={setPassword}
      />

      {/* Giriş yap butonu */}
      <TouchableOpacity onPress={handleSignIn}>
        <View style={styles.buttonContainer}>
          <Text style={styles.buttonText}> Giriş Yap </Text>
        </View>
      </TouchableOpacity>

      {/* E-posta doğrulama e-postasını tekrar gönderme linki */}
      <TouchableOpacity onPress={resendVerificationEmail}>
        <Text style={styles.resendLink}>E-posta doğrulama e-postasını tekrar gönder</Text>
      </TouchableOpacity>

      {/* OTP doğrulama için modal */}
      <Modal
        visible={isModalVisible}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalContainer}>
          <Text style={styles.modalText}>E-postanıza gelen doğrulama kodunu girin:</Text>
          <OTPInputView
            style={styles.otpInput}
            pinCount={6}
            autoFocusOnLoad
            codeInputFieldStyle={styles.otpInputField}
            onCodeFilled={(code) => {
              setOtp(code);
              setModalVisible(false);
              handleOTPVerification();
            }}
          />
        </View>
      </Modal>

      {/* Hata mesajı */}
      {errorMessage !== '' && (
        <Text style={styles.errorMessage}>{errorMessage}</Text>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
  },
  buttonText: {
    fontWeight: 'bold',
    fontSize: 16,
    color: 'white',
  },
  input: {
    height: 40,
    width: '60%',
    borderColor: 'gray',
    borderWidth: 0,
    borderBottomWidth: 1,
    borderBottomColor: 'gray',
    marginBottom: 12,
    paddingLeft: 8,
  },
  buttonContainer: {
    width: 150,
    height: 30,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 25,
    backgroundColor: '#00aff0',
    marginTop: 10,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 5,
    },
    shadowOpacity: 0.34,
    shadowRadius: 6.27,
    elevation: 10,
  },
  resendLink: {
    marginTop: 10,
    color: '#00aff0',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalText: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  otpInput: {
    width: '60%',
    height: 60,
    marginTop: 10,
  },
  otpInputField: {
    borderWidth: 0,
    borderBottomWidth: 1,
    borderBottomColor: 'gray',
    fontSize: 24,
  },
  errorMessage: {
    color: 'red',
    marginTop: 10,
  },
});

export default HomePage;
