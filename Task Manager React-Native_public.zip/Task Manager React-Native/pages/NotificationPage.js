import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Modal, TextInput, Alert } from 'react-native';
import firebase from 'firebase/compat/app';
import 'firebase/compat/firestore';
import { Feather } from '@expo/vector-icons';
import DropDownPicker from 'react-native-dropdown-picker';
import DateTimePickerModal from 'react-native-modal-datetime-picker';

const NotificationPage = ({ navigation }) => {
  const [notifyFromFirebase, setNotifyFromFirebase] = useState([]);
  const [selectedNotify, setSelectedNotify] = useState(null);
  const [isModalVisible, setModalVisible] = useState(false);
  const [duyuruAdi, setDuyuruAdi] = useState('');
  const [duyuruAciklama, setDuyuruAciklama] = useState('');
  const [priorityValue, setPriorityValue] = useState('');
  const [gorevItems, setGorevItems] = useState([
    { label: 'Normal', value: 'normal' },
    { label: 'Önemli', value: 'onemli' },
    { label: 'Çok Önemli', value: 'cok_onemli' },
  ]);
  const [statusItems, setStatusItems] = useState([
    { label: 'Yapılacak', value: 'yapilacak' },
    { label: 'Aktif', value: 'aktif' },
    { label: 'Bekleyen', value: 'bekleyen' },
    { label: 'Tamamlanan', value: 'tamamlanan' },
  ]);
  const [isDatePickerVisible2, setDatePickerVisibility2] = useState(false);

  // Firebase'den veri alma işlevi
  useEffect(() => {
    const fetchData = async () => {
      try {
        // Duyurular koleksiyonundan verileri al
        const notifyCollection = firebase.firestore().collection('duyurular');
        const querySnapshot = await notifyCollection.orderBy('duyuruTarihi', 'desc').get();

        if (!querySnapshot.empty) {
          const tasksData = querySnapshot.docs.map(doc => {
            const taskData = doc.data();
            const taskId = doc.id;
            const assignedPeople = await getAssignedPeople(taskData.priorityValue);
            return {
              id: taskId,
              duyuruAdi: taskData.duyuruAdi,
              aciklama: taskData.duyuruAciklama,
              priorityValue: taskData.priorityValue,
              statusValue: taskData.statusValue,
              duyuruTarihi: taskData.duyuruTarihi?.toDate(),
              assignedPeople: assignedPeople,
            };
          });

          setNotifyFromFirebase(tasksData);
        }
      } catch (error) {
        console.error('Firebase Hatası:', error);
      }
    };

    fetchData();
  }, []);

  // Atanmış kişileri getiren işlev
  const getAssignedPeople = async (priorityValue) => {
    try {
      if (!priorityValue) {
        return [];
      }

      // Verilen öncelik değerine göre atanmış kişileri getir
      const assignedPeopleCollection = firebase.firestore().collection('atananlar').where('priorityValue', '==', priorityValue);
      const atanilanlarSnapshot = await assignedPeopleCollection.get();

      if (!atanilanlarSnapshot.empty) {
        // Atanmış kişilerin baş harflerini alarak oluşturulan bir listeyi döndür
        const assignedPeopleList = atanilanlarSnapshot.docs.map(doc => {
          const adSoyad = doc.data().adSoyad;
          const initials = adSoyad.split(' ').map(word => word.charAt(0).toUpperCase()).join('');
          return initials;
        }) || [];
        return assignedPeopleList;
      }

      return [];
    } catch (error) {
      console.error('Firebase Hatası:', error);
      return [];
    }
  };

  // Duyuru güncelleme işlevi
  const handleUpdate = async (notifyId) => {
    try {
      // Seçili duyuruyu bul
      const selectedNotify = notifyFromFirebase.find((notify) => notify.id === notifyId);

      if (!selectedNotify) {
        console.error('Firebase Hatası: Seçili duyuru bulunamadı.');
        return;
      }

      // Modal'ı görünür yap ve seçili duyuruyu ayarla
      setSelectedNotify(selectedNotify);
      setModalVisible(true);
    } catch (error) {
      console.error('Firebase Hatası:', error);
    }
  };

  // Duyuru silme işlevi
  const handleDelete = async (notifyId) => {
    try {
      // Silinecek duyuruyu Firestore'dan sil
      await firebase.firestore().collection('duyurular').doc(notifyId).delete();
      // Verileri yeniden getir
      fetchData();
    } catch (error) {
      console.error('Firebase Hatası:', error);
      Alert.alert('Hata', 'Duyuru silinirken bir hata oluştu.');
    }
  };

  // Duyuru güncelleme işlevi
  const handleUpdateNotify = async () => {
    try {
      if (!selectedNotify || typeof selectedNotify.priorityValue !== 'string') {
        console.error('Firebase Hatası: Geçersiz priorityValue değeri.');
        return;
      }

      // Seçili duyuruyu güncelle
      await firebase.firestore().collection('duyurular').doc(selectedNotify.id).update(selectedNotify);
      // Modal'ı kapat ve verileri yeniden getir
      setModalVisible(false);
      fetchData();
    } catch (error) {
      console.error('Firebase Hatası:', error);
      Alert.alert('Hata', 'Duyuru güncellenirken bir hata oluştu.');
    }
  };

  // Liste öğelerini render etme işlevi
  const renderListItems = () => {
    if (!notifyFromFirebase || notifyFromFirebase.length === 0) {
      return <Text style={styles.noTasksText}>Henüz duyuru bulunmamaktadır.</Text>;
    }

    return notifyFromFirebase.map(notify => (
      <View style={styles.taskCard} key={notify.id}>
        <Text style={styles.taskTitle}>{notify.duyuruAdi}</Text>
        <Text style={styles.taskDescription}>{`Bu duyuru ${notify.aciklama} dir`}</Text>
        <Text style={styles.taskInfo}>
          <Text style={styles.boldText}>İlgili Görev:</Text> {notify.priorityValue}
        </Text>
        <Text style={styles.taskInfo}>
          <Text style={styles.boldText}>Duyuru Dur

          </Text>
          <Text style={styles.taskInfo}>
            <Text style={styles.boldText}>Duyuru Durumu:</Text> {notify.statusValue}
          </Text>
          <Text style={styles.taskInfo}>
            <Text style={styles.boldText}>Tarih:</Text> {notify.duyuruTarihi instanceof Date ? 
              notify.duyuruTarihi.toLocaleDateString('tr-TR') : 
              'Bilinmiyor'}
          </Text>
          <View style={styles.assignedPeopleContainer}>
            {notify.assignedPeople.map((initials, index) => (
              <View key={index} style={styles.personCircle}>
                <Text style={styles.personInitials}>{initials}</Text>
              </View>
            ))}
          </View>
          <View style={styles.buttonContainer}>
            <TouchableOpacity
              style={styles.button}
              onPress={() => handleUpdate(notify.id)}>
              <Feather name="edit" size={20} color="white" />
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.button]}
              onPress={() => handleDelete(notify.id)}>
              <Feather name="trash-2" size={20} color="white" />
            </TouchableOpacity>
          </View>
        </View>
      ));
    };
  
    return (
      <View style={styles.container}>
        <ScrollView>
          {renderListItems()}
        </ScrollView>
  
        <Modal
          visible={isModalVisible}
          transparent={true}
          animationType="slide"
          onRequestClose={() => setModalVisible(false)}
        >
          <View style={styles.modalContainer}>
            <Text style={styles.modalTitle}>Duyuru Güncelle</Text>
            <TextInput
              style={styles.input}
              placeholder="Duyuru Adı"
              value={selectedNotify?.duyuruAdi}
              onChangeText={setDuyuruAdi}
            />
            {/* Diğer girişler ve seçimler buraya gelecek */}
            <TouchableOpacity style={styles.button} onPress={handleUpdateNotify}>
              <Text style={styles.buttonText}>Güncelle</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.button} onPress={() => setModalVisible(false)}>
              <Text style={styles.buttonText}>Kapat</Text>
            </TouchableOpacity>
          </View>
        </Modal>
      </View>
    );
  };  

  return (
    <ScrollView contentContainerStyle={styles.container}>
      {renderListItems()} {/* Duyuru listesi */}
      <Modal
        visible={isModalVisible}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Duyuru Güncelle</Text>
  
            {/* Duyuru Adı Girişi */}
            <TextInput
              style={styles.input}
              placeholder="Duyuru Adı"
              value={selectedNotify ? selectedNotify.duyuruAdi : ''}
              onChangeText={(text) => setDuyuruAdi(text)}
            />
  
            {/* İlgili Görevi Seçme */}
            <View style={styles.dropdown}>
              <DropDownPicker
                open={gorevOpen}
                value={selectedNotify ? selectedNotify.priorityValue : null}
                items={gorevAdlari}
                setOpen={setGorevOpen}
                setValue={(value) => setSelectedNotify({ ...selectedNotify, priorityValue: value })}
                setItems={setGorevAdlari}
                containerStyle={[styles.input, { zIndex: 3 }]}
                theme="LIGHT"
                placeholder='İlgili Görevi Seçin'
              />
            </View>
  
            {/* Görev Durumu Seçme */}
            <View style={styles.dropdown}>
              <DropDownPicker
                open={statusOpen}
                value={selectedNotify ? selectedNotify.statusValue : null}
                items={statusItems}
                setOpen={setStatusOpen}
                setValue={(value) => setSelectedNotify({ ...selectedNotify, statusValue: value })}
                setItems={setStatusItems}
                containerStyle={[styles.input, { zIndex: 2 }]}
                theme="LIGHT"
                placeholder='Görev Durumu Seçin'
              />
            </View>
  
            {/* Duyuru Tarihi Seçme */}
            <TouchableOpacity onPress={showDatePicker2}>
              <TextInput
                style={styles.input}
                placeholder="Duyuru Tarihi"
                value={
                  selectedNotify
                    ? selectedNotify.duyuruTarihi instanceof Date
                      ? selectedNotify.duyuruTarihi.toLocaleDateString('tr-TR')
                      : 'Tarih Seçiniz'
                    : 'Tarih Seçiniz'
                }
                editable={false}
              />
            </TouchableOpacity>
            <DateTimePickerModal
              isVisible={isDatePickerVisible2}
              mode="date"
              onConfirm={handleConfirm2}
              onCancel={hideDatePicker2}
            />
  
            {/* Açıklama Girişi */}
            <TextInput
              style={[styles.input, { height: 100 }]}
              placeholder="Açıklama"
              multiline={true}
              numberOfLines={2}
              value={selectedNotify ? selectedNotify.aciklama : ''}
              onChangeText={(text) => setDuyuruAciklama(text)}
            />
  
            {/* Güncelleme ve İptal Butonları */}
            <View styles={styles.buttonContainer}>
              <View style={styles.buttonContainer}>
                {/* Güncelle Butonu */}
                <TouchableOpacity
                  style={[styles.button, styles.updateButton]}
                  onPress={handleUpdateNotify}
                >
                  <Feather name="edit" size={20} color="white" />
                </TouchableOpacity>
                {/* İptal Butonu */}
                <TouchableOpacity
                  style={[styles.button, styles.cancelButton]}
                  onPress={() => setModalVisible(false)}
                >
                  <Feather name="x-circle" size={20} color="white" />
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </View>
      </Modal>
    </ScrollView>
  );

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    padding: 16,
  },
  taskCard: {
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowColor: '#FF0000',
    elevation:5,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowRadius: 4,
    shadowOpacity: 0.2,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 10,
  },
  button: {
    backgroundColor: '#00aff0',
    padding: 10,
    width: 40,
    height: 40,
    borderRadius: 25,
    opacity: 0.8,
    elevation: 10,
    shadowColor: '#000',
    shadowOffset: {
      width: 100,
      height: 2,
    },
    marginHorizontal: 5,
    alignItems: 'center',
  },
  taskTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  taskDescription: {
    fontSize: 16,
    marginBottom: 8,
  },
  taskInfo: {
    fontSize: 14,
    color: '#555',
    marginBottom: 4,
  },
  noTasksText: {
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
    marginTop: 20,
  },
  boldText: {
    fontWeight: 'bold',
  },
  personCircle: {
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: '#00aff0',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 8,
  },
  assignedPeopleContainer: {
    flexDirection: 'row',
    marginTop: 8,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 4,
    padding: 8,
    marginBottom: 16,
  },
  personInitials:{
    color: 'white',
    fontWeight: 'bold',
  },
  buttonText: {
    color: 'white',
    fontWeight: 'bold',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },

  modalContent: {
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 16,
    width: '80%',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  modalButtonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  updateButton: {
    backgroundColor: '#00aff0',
  },
  cancelButton: {
    backgroundColor: '#00aff0',
  },
  
});

export default NotificationPage;