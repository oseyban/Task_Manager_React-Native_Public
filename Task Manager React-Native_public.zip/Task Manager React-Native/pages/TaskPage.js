import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Modal,
  TextInput,
  Alert,
} from 'react-native';
import firebase from 'firebase/compat/app';
import 'firebase/compat/firestore';
import { Feather } from '@expo/vector-icons';
import DateTimePickerModal from 'react-native-modal-datetime-picker';
import DropDownPicker from 'react-native-dropdown-picker';

const TaskPage = ({ navigation }) => {
  const [tasksFromFirebase, setTasksFromFirebase] = useState([]);
  const [selectedTask, setSelectedTask] = useState(null);
  const [isModalVisible, setModalVisible] = useState(false);
  const [updatedTaskName, setUpdatedTaskName] = useState('');
  const [updatedTaskAciklama, setUpdatedTaskAciklama] = useState('');
  const [updatedPriority, setUpdatedPriority] = useState('');
  const [updatedStatus, setUpdatedStatus] = useState('');
  const [updatedDate, setUpdatedDate] = useState();
  const [isVisible, setDatePickerVisible] = useState(false);

  // State for priority dropdown
  const [priorityOpen, setPriorityOpen] = useState(false);
  const [priorityValue, setPriorityValue] = useState('');
  const [priorityItems, setPriorityItems] = useState([
    { label: 'Normal', value: 'normal' },
    { label: 'Önemli', value: 'onemli' },
    { label: 'Çok Önemli', value: 'cok_onemli' },
  ]);

  // State for status dropdown
  const [statusOpen, setStatusOpen] = useState(false);
  const [statusValue, setStatusValue] = useState('');
  const [statusItems, setStatusItems] = useState([
    { label: 'Bekleyen', value: 'bekleyen' },
    { label: 'Yapılacak', value: 'yapilacak' },
    { label: 'Aktif', value: 'aktif' },
    { label: 'Tamamlandı', value: 'tamamlandi' },
  ]);

  // Function to delete a task
  const handleDelete = async (taskId) => {
    try {
      // Delete assigned people sub-collection
      const assignedPeopleCollection = await firebase.firestore().collection('gorevler').doc(taskId).collection('atananlar').get();
      const deleteAssignedPeoplePromises = assignedPeopleCollection.docs.map(doc => doc.ref.delete());
      await Promise.all(deleteAssignedPeoplePromises);
  
      // Delete the task
      await firebase.firestore().collection('gorevler').doc(taskId).delete();
      fetchData(); 
    } catch (error) {
      console.error('Firebase Error:', error);
      Alert.alert('Error', 'An error occurred while deleting the task.');
    }
  };

  // Function to fetch tasks from Firebase
  const fetchData = async () => {
    try {
      const tasksCollection = firebase.firestore().collection('gorevler');
      const querySnapshot = await tasksCollection.orderBy('gorevTarihi', 'desc').get();
  
      if (!querySnapshot.empty) {
        const tasksData = [];
  
        for (const doc of querySnapshot.docs) {
          const taskData = doc.data();
          const taskId = doc.id;
  
          const assignedPeople = await getAssignedPeople(taskId);
  
          tasksData.push({
            id: taskId,
            taskName: taskData.gorevAdi,
            description: taskData.aciklama,
            priorityValue: taskData.priorityValue,
            statusValue: taskData.statusValue,
            updatedDate: taskData.gorevTarihi,
            assignedPeople: assignedPeople,
          });
        }
  
        setTasksFromFirebase(tasksData);
      }
    } catch (error) {
      console.error('Firebase Error:', error);
    }
  };

  // Function to get assigned people for a task
  const getAssignedPeople = async (taskId) => {
    try {
      const assignedPeopleCollection = await firebase.firestore().collection('gorevler').doc(taskId).collection('assignedPeople').get();
      return assignedPeopleCollection.docs.map(doc => doc.data().initials);
    } catch (error) {
      console.error('Firebase Error:', error);
      return [];
    }
  };

  // Fetch tasks on component mount
  useEffect(() => {
    fetchData();
  }, []);

  // Function to handle task update
  const handleUpdate = async (taskId) => {
    try {
      const selectedTask = tasksFromFirebase.find((task) => task.id === taskId);
      const taskDetails = await firebase.firestore().collection('gorevler').doc(taskId).get();
      const taskData = taskDetails.data();
  
      if (!taskData) {
        console.error('Firebase Error: Task details not found.');
        return;
      }
  
      selectedTask.gorevAdi = taskData.gorevAdi;
      selectedTask.aciklama = taskData.aciklama;
      selectedTask.priorityValue = taskData.priorityValue;
      selectedTask.statusValue = taskData.statusValue;
      selectedTask.gorevTarihi = taskData.gorevTarihi;
  
      setSelectedTask(selectedTask);
      setUpdatedTaskName(selectedTask.gorevAdi);
      setUpdatedTaskAciklama(selectedTask.aciklama);
      setUpdatedPriority(selectedTask.priorityValue);
      setUpdatedStatus(selectedTask.statusValue);
      setUpdatedDate(new Date(selectedTask.gorevTarihi));
      setPriorityValue(selectedTask.priorityValue);
      setStatusValue(selectedTask.statusValue);
      setDatePickerVisible(false);
      setModalVisible(true);
    } catch (error) {
      console.error('Firebase Error:', error);
    }
  };
  
  // Function to handle date confirmation
  const handleConfirmDate = (date) => {
    const formattedDate = firebase.firestore.Timestamp.fromDate(date
      setUpdatedDate(formattedDate);
      hideDatePicker();
    };
  
    // Function to update the task
    const handleUpdateTask = async () => {
      try {
        await firebase.firestore().collection('gorevler').doc(selectedTask.id).update({
          gorevAdi: updatedTaskName,
          priorityValue: updatedPriority,
          statusValue: updatedStatus,
          gorevTarihi: updatedDate,
          aciklama: updatedTaskAciklama,
        });
  
        setModalVisible(false);
        fetchData();
      } catch (error) {
        console.error('Firebase Error:', error);
        Alert.alert('Error', 'An error occurred while updating the task.');
      }
    };
  
    // Function to show date picker
    const showDatePicker = () => {
      setDatePickerVisible(true);
    };
  
    // Function to hide date picker
    const hideDatePicker = () => {
      setDatePickerVisible(false);
    };
  
    // Function to render list items
    const renderListItems = () => {
      if (!tasksFromFirebase || tasksFromFirebase.length === 0) {
        return <Text style={styles.noTasksText}>There are no tasks yet.</Text>;
      }
  
      return tasksFromFirebase.map((task) => (
        <View style={styles.taskCard} key={task.id}>
          <Text style={styles.taskTitle}>{task.taskName}</Text>
          <Text style={styles.taskDescription}>{`This task is ${task.description}.`}</Text>
          <Text style={styles.taskInfo}>
            <Text style={styles.boldText}>Priority:</Text> {task.priorityValue}
          </Text>
          <Text style={styles.taskInfo}>
            <Text style={styles.boldText}>Status:</Text> {task.statusValue}
          </Text>
          <Text style={styles.taskInfo}>
            <Text style={styles.boldText}>Date:</Text>
            {new Date(task.taskDate.seconds * 1000).toLocaleString()}
          </Text>
          <View style={styles.assignedPeopleContainer}>
            {task.assignedPeople.map((initials, index) => (
              <View key={index} style={styles.personCircle}>
                <Text style={styles.personInitials}>{initials}</Text>
              </View>
            ))}
          </View>
          <View style={styles.buttonContainer}>
            <TouchableOpacity
              style={styles.button}
              onPress={() => handleUpdate(task.id)}>
              <Feather name="edit" size={20} color="white" />
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.button]}
              onPress={() => handleDelete(task.id)}>
              <Feather name="trash-2" size={20} color="white" />
            </TouchableOpacity>
          </View>
        </View>
      ));
    };
  
    return (
      <ScrollView contentContainerStyle={styles.container}>
        {renderListItems()}
        <Modal
          visible={isModalVisible}
          transparent={true}
          animationType="slide"
          onRequestClose={() => setModalVisible(false)}>
          <View style={styles.modalContainer}>
            <View style={styles.modalContent}>
              <Text style={styles.modalTitle}>Update Task</Text>
              <TextInput
                style={styles.input}
                placeholder="Task Name"
                value={updatedTaskName}
                onChangeText={(text) => setUpdatedTaskName(text)}
              />
              <View style={styles.dropdown}>
                <DropDownPicker
                  open={priorityOpen}
                  value={priorityValue}
                  items={priorityItems}
                  setOpen={setPriorityOpen}
                  setValue={setPriorityValue}
                  setItems={setPriorityItems}
                  containerStyle={[styles.input, { zIndex: 3 }]}
                  theme="LIGHT"
                  placeholder='Select Task Priority'
                />
              </View>
              <View style={styles.dropdown}>
                <DropDownPicker
                  open={statusOpen}
                  value={statusValue}
                  items={statusItems}
                  setOpen={setStatusOpen}
                  setValue={setStatusValue}
                  setItems={setStatusItems}
                  containerStyle={[styles.input, { zIndex: 2 }]}
                  theme="LIGHT"
                  placeholder='Select Task Status'
                />
              </View>
              <TouchableOpacity onPress={showDatePicker}>
                <TextInput
                  style={styles.input}
                  placeholder="Task Date"
                  value={updatedDate ?
                    (updatedDate instanceof Date && !isNaN(updatedDate))
                      ? updatedDate.toLocaleDateString('en-US')
                      : updatedDate
                    : 'Select Date'}
                  editable={false}
                />
              </TouchableOpacity>
              <DateTimePickerModal
                isVisible={isVisible}
                mode="date"
                onConfirm={handleConfirmDate}
                onCancel={hideDatePicker}
              />
              <TextInput
                style={styles.input}
                placeholder="Task Description"
                value={updatedTaskAciklama}
                onChangeText={(text) => setUpdatedTaskAciklama(text)}
              />
              <View style={styles.buttonContainer}>
                <TouchableOpacity
                  style={[styles.button]}
                  onPress={handleUpdateTask}>
                  <Feather name="edit" size={20} color="white" />
                  <Text style={styles.buttonText}></Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.button]}
                  onPress={() => setModalVisible(false)}>
                  <Feather name="x-circle" size={20} color="white" />
                  <Text style={styles.buttonText}></Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </Modal>
      </ScrollView>
    );
  };


const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    padding: 16,
  },
  taskCard: {
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#FF0000',
    elevation: 5,
    shadowOffset: {
      width: 0,
      height: 22,
    },
    shadowRadius: 4,
    shadowOpacity: 0.2,
  },
  taskTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  taskDescription: {
    fontSize: 16,
    marginBottom: 8,
  },
  taskInfo: {
    fontSize: 14,
    color: '#555',
    marginBottom: 4,
  },
  noTasksText: {
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
    marginTop: 20,
  },
  boldText: {
    fontWeight: 'bold',
  },
  personCircle: {
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: '#00aff0',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 8,
  },
  assignedPeopleContainer: {
    flexDirection: 'row',
    marginTop: 8,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 10,
  },
  button: {
    backgroundColor: '#00aff0',
    padding: 10,
    width: 40,
    height: 40,
    borderRadius: 25,
    opacity: 0.8,
    elevation: 10,
    shadowColor: '#000',
    shadowOffset: {
      width: 100,
      height: 2,
    },
    marginHorizontal: 5,
    alignItems: 'center',
  },
  buttonText: {
    color: 'white',
    fontWeight: 'bold',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 16,
    width: '80%',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 4,
    padding: 8,
    marginBottom: 16,
  },
  modalButtonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  updateButton: {
    backgroundColor: '#00aff0',
  },
  cancelButton: {
    backgroundColor: '#ccc',
  },
});

export default TaskPage;
