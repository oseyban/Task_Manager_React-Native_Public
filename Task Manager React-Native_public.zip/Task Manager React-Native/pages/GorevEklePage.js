import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Modal,
  TextInput,
  Button,
} from 'react-native';
import DropDownPicker from 'react-native-dropdown-picker';
import DateTimePickerModal from "react-native-modal-datetime-picker";
import firebase from 'firebase/compat/app';
import 'firebase/compat/firestore';

const GorevEklePage = ({ navigation }) => {
  // Görev ekle modalının görünürlüğünü kontrol etmek için state'ler
  const [isGorevEkleModalVisible2, setGorevEkleModalVisible2] = useState(false);

  // Görev bilgilerini tutmak için state'ler
  const [gorevAdi, setGorevAdi] = useState('');
  const [gorevTarihi, setGorevTarihi] = useState('');  
  const [aciklama, setAciklama] = useState('');
  const [priorityOpen, setPriorityOpen] = useState(false);
  const [priorityValue, setPriorityValue] = useState('');
  const [priorityItems, setPriorityItems] = useState([
    { label: 'Normal', value: 'normal' },
    { label: 'Önemli', value: 'önemli' },
    { label: 'Çok Önemli', value: 'çok_önemli' }  
  ]);
  const [isDatePickerVisible, setDatePickerVisibility] = useState(false);

  // Date Picker'ın görünürlüğünü kontrol etmek için fonksiyonlar
  const showDatePicker = () => setDatePickerVisibility(true);
  const hideDatePicker = () => setDatePickerVisibility(false);

  // Date Picker'da seçilen tarihi işlemek için fonksiyon
  const handleConfirm = (date) => {
    setGorevTarihi(date.toISOString());
    hideDatePicker();
  };

  // Görev ekle fonksiyonu
  const gorevEkle = async () => {
    try {
      // Boş alan kontrolü
      if (!gorevAdi || !priorityValue || !gorevTarihi || !aciklama) {
        console.log('Lütfen gerekli alanları doldurun');
        toggleGorevEkleModal2();
        return;
      }

      // Firestore'a görevi ekleme
      const userDocRef1 = firebase.firestore().collection('gorevler').doc(); 
      await userDocRef1.set({
        gorevAdi,
        priorityValue,
        gorevTarihi,
        aciklama,
      });

      // State'leri sıfırlama
      setGorevAdi('');
      setPriorityValue('');
      setGorevTarihi('');
      setAciklama('');

      // Başarı mesajı gösterme
      alert('Görev Başarıyla Eklendi');
      console.log('Görev başarıyla eklendi. Belge ID:', userDocRef1.id);
    } catch (error) {
      console.error('Kayıt hatası:', error.message);
      alert(error.message);
    }
  };

  // Görev ekle modalını açıp kapatma fonksiyonu
  const toggleGorevEkleModal2 = () => {
    setGorevEkleModalVisible2(!isGorevEkleModalVisible2);
    // State'leri sıfırlama
    setGorevAdi('');
    setPriorityValue('');
    setGorevTarihi('');
    setAciklama('');
  };

  return (
    <View style={{ flex: 1 }}>
      {/* Görev Ekle Modal */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={isGorevEkleModalVisible2}
        onRequestClose={() => toggleGorevEkleModal2()}>
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Görev Ekle</Text>

            {/* Görev Adı */}
            <TextInput
              style={styles.input}
              placeholder="Görev Adı"
              value={gorevAdi}
              onChangeText={(text) => setGorevAdi(text)}
            />

            {/* Görev Önceliği */}
            <DropDownPicker
              open={priorityOpen}
              value={priorityValue}
              items={priorityItems}
              setOpen={setPriorityOpen}
              setValue={setPriorityValue}
              setItems={setPriorityItems}
              containerStyle={[styles.input, { zIndex: 3 }]}
              theme="LIGHT"
              placeholder='Görev Önceliği Seçin'
            />

            {/* Görev Tarihi */}
            <TouchableOpacity onPress={showDatePicker}>
              <TextInput
                style={styles.input}
                placeholder="Görev Tarihi"
                value={gorevTarihi}
                editable={false}
              />
            </TouchableOpacity>
            <DateTimePickerModal
              isVisible={isDatePickerVisible}
              mode="date"
              onConfirm={handleConfirm}
              onCancel={hideDatePicker}
            />

            {/* Açıklama */}
            <TextInput
              style={[styles.input, { height: 100 }]}
              placeholder="Açıklama"
              multiline={true}
              numberOfLines={3}
              value={aciklama}
              onChangeText={(text) => setAciklama(text)}
            />

            {/* Kaydet ve Kapat Butonları */}
            <View style={styles.buttonContainer}>
              <Button title="Kaydet" onPress={gorevEkle} />
              <Button title="Kapat" onPress={toggleGorevEkleModal2} />
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}
const styles = StyleSheet.create({
    container: {
      flexGrow: 1,
      padding: 16,
    },
    sectionTitle: {
      fontSize: 20,
      fontWeight: 'bold',
      marginBottom: 16,
    },
    taskCard: {
      backgroundColor: '#fff',
      borderRadius: 8,
      padding: 16,
      marginBottom: 16,
      shadowColor: '#000',
      shadowOffset: {
        width: 0,
        height: 2,
      },
      shadowRadius: 4,
      shadowOpacity: 0.2,
    },
    taskTitle: {
      fontSize: 18,
      fontWeight: 'bold',
      marginBottom: 8,
    },
    taskDescription: {
      fontSize: 16,
      marginBottom: 8,
    },
    taskInfo: {
      fontSize: 14,
      color: '#555',
      marginBottom: 4,
    },
    assignedPeopleContainer: {
      flexDirection: 'row',
      marginTop: 8,
    },
    personCircle: {
      width: 30,
      height: 30,
      borderRadius: 15,
      backgroundColor: '#00aff0',
      justifyContent: 'center',
      alignItems: 'center',
      marginRight: 8,
    },
    personInitials: {
      color: '#fff',
      fontWeight: 'bold',
    },
    boldText: {
      fontWeight: 'bold',
    },
    usttab: {
      flexDirection: 'row',
      justifyContent: 'space-around',
      alignItems: 'center',
      backgroundColor: '#fff',
      paddingVertical: 10,
      shadowColor: '#000',
      shadowOffset: {
        width: 0,
        height: 2,
      },
      shadowRadius: 4,
      shadowOpacity: 0.2,
    },
    usttabButton: {
      paddingHorizontal: 20,
      paddingVertical: 10,
      borderRadius: 8,
      borderWidth: 1,
      borderColor: '#00aff0',
    },
    usttabButtonText: {
      fontWeight: 'bold',
      color: '#00aff0',
    },
    modalContainer: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: 'rgba(0, 0, 0, 0.5)',
    },
    modalContent: {
      width: '90%',
      padding: 20,
      backgroundColor: '#fff',
      borderRadius: 8,
    },
    modalTitle: {
      fontSize: 18,
      fontWeight: 'bold',
      marginBottom: 10,
    },
    input: {
      borderWidth: 1,
      borderColor: '#ccc',
      borderRadius: 8,
      marginBottom: 10,
      padding: 8,
    },
    buttonContainer: {
      flexDirection: 'row',
      justifyContent: 'space-around',
    },
    modalSubtitle: {
      fontSize: 16,
      fontWeight: 'bold',
      marginTop: 10,
      marginBottom: 5,
    },
    personListContainer: {
      maxHeight: 150,
      marginBottom: 10,
    },
    gorevAtaItem: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 5,
    },
    selectedText: {
      color: 'green',
    },
    unselectedText: {
      color: 'red',
    },
    dropdown: {
      alignItems: 'center',
      justifyContent: 'center',
      paddingHorizontal: 15
  }
  });
export default GorevEklePage;