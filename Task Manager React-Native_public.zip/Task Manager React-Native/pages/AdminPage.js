import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Modal,
  TextInput,
  Button,
} from 'react-native';
import TaskAssignmentModal from './TaskAssignmentModal'; // Görev Atama Modalı
import DropDownPicker from 'react-native-dropdown-picker'; // DropDown bileşeni
import DateTimePickerModal from "react-native-modal-datetime-picker"; // Tarih seçim modalı
import { auth, firestore, firebase } from './firebase'; // Firebase bağlantısı

import moment from 'moment'; // Tarih formatlama kütüphanesi

const AdminPage = ({ navigation }) => {
  // Görev atama ve ekleme modallarının görünürlük durumu
  const [isModalTaskAssignVisible, setModalTaskAssignVisible] = useState(false);
  const [isTaskAddModalVisible, setTaskAddModalVisible] = useState(false);

  // Görev detayları için state'ler
  const [taskName, setTaskName] = useState('');
  const [taskDate, setTaskDate] = useState();  
  const [description, setDescription] = useState('');
  
  // Öncelikler için state'ler
  const [priorityOpen, setPriorityOpen] = useState(false);
  const [priorityValue, setPriorityValue] = useState('');
  const [priorityItems, setPriorityItems] = useState([
    { label: 'Normal', value: 'normal' },
    { label: 'Önemli', value: 'onemli' },
    { label: 'Çok Önemli', value: 'cok_onemli' }  
  ]);
  
  // Görev durumları için state'ler
  const [statusOpen, setStatusOpen] = useState(false);
  const [statusValue, setStatusValue] = useState('');
  const [statusItems, setStatusItems] = useState([
    { label: 'Bekleyen', value: 'bekleyen' },
    { label: 'Yapılacak', value: 'yapilacak' },
    { label: 'Aktif', value: 'aktif' },  
    { label: 'Tamamlandı', value: 'tamamlandi' }  
  ]);

  // Diğer state'ler
  const [taskOpen, setTaskOpen] = useState(false);
  const [taskItems, setTaskItems] = useState([]);
  const [lastTask, setLastTask] = useState({});
  const [lastAnnouncement, setLastAnnouncement] = useState({});
  const [assignedPeople, setAssignedPeople] = useState([]);
  const [assignedPeople1, setAssignedPeople1] = useState([]);

  // Görev adlarını Firestore'dan alma
  useEffect(() => {
    const getTaskNamesFromFirebase = async () => {
      try {
        const taskCollection = firebase.firestore().collection('tasks');
        const snapshot = await taskCollection.get();
        const newTaskItems = snapshot.docs.map(doc => ({
          label: doc.data().taskName,
          value: doc.data().taskName,
        }));

        // State'i güncelle
        setTaskItems(newTaskItems);
      } catch (error) {
        console.error('Firebase Hatası:', error);
      }
    };

    // Fonksiyonu çağır
    getTaskNamesFromFirebase();
  }, []);


// Görev ekleme fonksiyonu
const addTask = async () => {
  try {
    // Gerekli alanların doldurulup doldurulmadığını kontrol etme
    if (!taskName || !priorityValue || !statusValue || !taskDate || !description) {
      console.log('Lütfen gerekli alanları doldurun');
      toggleTaskAddModal();
      return;
    }

    // Yeni bir görev belgesi oluşturma
    const taskDocRef = firebase.firestore().collection('tasks').doc(); 
    await taskDocRef.set({
      taskName,
      priorityValue,
      statusValue,
      taskDate,
      description,
    });

    // Son görevin referansını güncelleme
    const lastTaskRef = firebase.firestore().collection('LastOperations').doc('lastTask');
    await lastTaskRef.set({
      taskName,
      priorityValue,
      statusValue,
      taskDate,
      description,
    });

    // State'leri temizleme
    setTaskName('');
    setPriorityValue('');
    setSelectedStatus('');
    setTaskDate();
    setDescription('');

    // Kullanıcıya bilgi verme
    alert('Görev Başarıyla Eklendi');
    console.log('Görev başarıyla eklendi. Belge ID:', taskDocRef.id);
    toggleTaskAddModal();
  } catch (error) {
    console.error('Kayıt hatası:', error.message);
    alert(error.message);
  }
};

// Duyuru kaydetme fonksiyonu
const saveAnnouncement = async () => {
  try {
    // Gerekli alanların doldurulup doldurulmadığını kontrol etme
    if (!announcementName || !priorityValue || !statusValue || !announcementDate || !announcementDescription) {
      console.log('Lütfen gerekli alanları doldurun'); 
      return;
    }

    // Yeni bir duyuru belgesi oluşturma
    const announcementsCollection = firebase.firestore().collection('announcements');
    const announcementDocRef = announcementsCollection.doc();

    await announcementDocRef.set({
      announcementName,
      priorityValue,
      statusValue,
      announcementDate,
      announcementDescription,
    });

    // Son duyurunun referansını güncelleme
    const lastAnnouncementCollection = firebase.firestore().collection('LastOperations').doc('lastAnnouncement');
    await lastAnnouncementCollection.set({
      announcementName,
      priorityValue,
      statusValue,
      announcementDate,
      announcementDescription,
    });

    // State'leri temizleme
    setAnnouncementName('');
    setPriorityValue('');
    setStatusValue('');
    setAnnouncementDate();
    setAnnouncementDescription('');

    // Kullanıcıya bilgi verme
    console.log('Duyuru başarıyla eklendi. Belge ID:', announcementDocRef.id);
    alert('Duyuru Başarıyla Eklendi');
    toggleAnnouncementAddModal();
  } catch (error) {
    console.error('Duyuru ekleme hatası:', error.message);
  }
};

// Son işlemleri Firestore'dan alma
useEffect(() => {
  const getLastOperationsFromFirebase = async () => {
    try {
      // Son görevin verilerini alma
      const tasksRef = firebase.firestore().collection('tasks');
      const lastTaskQuery = await tasksRef.orderBy('taskDate', 'desc').limit(1).get();

      if (!lastTaskQuery.empty) {
        const lastTaskDoc = lastTaskQuery.docs[0];
        const lastTaskData = lastTaskDoc.data();
        const taskDate = lastTaskData.taskDate.toDate();
        lastTaskData.taskDate = taskDate.toLocaleDateString();
        setLastTask(lastTaskData);

        // Son göreve atanmış kişileri alma
        const assignedPeopleRef1 = lastTaskDoc.ref.collection('assignedPeople');
        const assignedPeopleQuery1 = await assignedPeopleRef1.get();
        const assignedPeopleData1 = assignedPeopleQuery1.docs.map(doc => doc.data().fullName);
        const assignedPeopleData2 = assignedPeopleData1.join(', ');

        if (assignedPeopleData2 && assignedPeopleData2.length > 0) {
          const initialsArray1 = assignedPeopleData2.split(',').map(fullName => {
            const initials1 = fullName.split(' ').map(word => word.charAt(0).toUpperCase()).join('');
            return { initials1 };
          });

          // State'i güncelleme
          setAssignedPeople1(initialsArray1);
        }
      }

      // Son duyurunun verilerini alma
      const announcementsRef = firebase.firestore().collection('announcements');
      const lastAnnouncementQuery = await announcementsRef.orderBy('announcementDate', 'desc').

      const lastAnnouncementQuery = await announcementsRef.orderBy('announcementDate', 'desc').limit(1).get();

      if (!lastAnnouncementQuery.empty) {
        const lastAnnouncementDoc = lastAnnouncementQuery.docs[0];
        const lastAnnouncementData = lastAnnouncementDoc.data();
        const announcementDate = lastAnnouncementData.announcementDate.toDate();
        lastAnnouncementData.announcementDate = announcementDate.toLocaleDateString(); 
        setLastAnnouncement(lastAnnouncementData);

        // Son duyuruya atanmış kişileri alma
        const assignedPeopleRef = lastAnnouncementDoc.ref.collection('assignedPeople');
        const assignedPeopleQuery = await assignedPeopleRef.get();
        const assignedPeopleData = assignedPeopleQuery.docs.map(doc => doc.data().fullName);
        const assignedPeopleData1 = assignedPeopleData.join(', ');

        if (assignedPeopleData1 && assignedPeopleData1.length > 0) {
          const initialsArray = assignedPeopleData1.split(',').map(fullName => {
            const initials = fullName.split(' ').map(word => word.charAt(0).toUpperCase()).join('');
            return { initials };
          });

          // State'i güncelleme
          setAssignedPeople(initialsArray);
        }
      }

      // Tüm görevleri alma
      const allTasksRef = firebase.firestore().collection('tasks');
      const allTasksQuery = await allTasksRef.get();

      allTasksQuery.forEach(async (taskDoc) => {
        const taskName = taskDoc.data().taskName;
        if (taskName === lastAnnouncementData.announcementName) {
          const assignedPeopleRef = taskDoc.ref.collection('assignedPeople');
          const assignedPeopleQuery = await assignedPeopleRef.get();
          const assignedPeopleData = assignedPeopleQuery.docs.map(doc => doc.data().fullName);

          // İlgili görevin atanmış kişilerini kullanabilirsiniz
        }
      });
    } catch (error) {
      console.error('Firebase Hatası:', error);
    }
  };

  getLastOperationsFromFirebase();
}, []);


return (
  <View style={{ flex: 1 }}>
    {/* Üst tab menü */}
    <View style={styles.usttab}>
      <TouchableOpacity
        style={styles.usttabButton}
        onPress={toggleGorevEkleModal}>
        <Text style={styles.usttabButtonText}>Görev Ekle</Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={styles.usttabButton}
        onPress={openModal}>
        <Text style={styles.usttabButtonText}>Görev Ata</Text>  
      </TouchableOpacity>
      <TouchableOpacity
        style={styles.usttabButton}
        onPress={toggleDuyuruEkleModal}>
        <Text style={styles.usttabButtonText}>Duyuru Ekle</Text>
      </TouchableOpacity>
    </View>

    {/* Görev Atama Modal */}
    <TaskAssignmentModal isVisible={isModalGorevAtaVisible} onClose={closeModal} />

    {/* Ana içerik */}
    <ScrollView contentContainerStyle={styles.container}>
      {/* Son Eklenen Görev */}
      <Text style={styles.sectionTitle}>Son Eklenen Görev</Text>
      <View style={styles.taskCard}>
        <Text style={styles.taskTitle}><Text style={styles.boldText}>Görev Adı : </Text>{sonGorev.gorevAdi}</Text>
        <Text style={styles.taskInfo}><Text style={styles.boldText}>Görev Önceliği : </Text>{sonGorev.priorityValue}</Text>
        <Text style={styles.taskInfo}><Text style={styles.boldText}>Görev Durumu : </Text>{sonGorev.statusValue}</Text>
        <Text style={styles.taskInfo}><Text style={styles.boldText}>Tarih : </Text>{sonGorev.gorevTarihi}</Text>
        <Text style={styles.taskInfo}><Text style={styles.boldText}>Açıklama : </Text>{sonGorev.aciklama}</Text>
        <View style={styles.assignedPeopleContainer}>
          {/* Atanan kişilerin baş harfleri */}
          {assignedPeople1.map((person, index) => (
            <View key={index} style={styles.personCircle}>
              <Text style={styles.personInitials}>{person.initials1}</Text>
            </View>
          ))}
        </View>
      </View>

      {/* Son Eklenen Duyuru */}
      <Text style={styles.sectionTitle}>Son Eklenen Duyuru</Text>
      <View style={styles.taskCard}>
        <Text style={styles.taskTitle}><Text style={styles.boldText}>Duyuru Adı : </Text>{sonDuyuru.duyuruAdi}</Text>
        <Text style={styles.taskInfo}><Text style={styles.boldText}>İlgili Görev Adı : </Text>{sonDuyuru.priorityValue}</Text>
        <Text style={styles.taskInfo}><Text style={styles.boldText}>Görev Durumu : </Text>{sonDuyuru.statusValue}</Text>
        <Text style={styles.taskInfo}><Text style={styles.boldText}>Tarih : </Text>{sonDuyuru.duyuruTarihi}</Text>
        <Text style={styles.taskInfo}><Text style={styles.boldText}>Açıklama :</Text> {sonDuyuru.duyuruAciklama}</Text>
        <View style={styles.assignedPeopleContainer}>
          {/* Atanan kişilerin baş harfleri */}
          {assignedPeople.map((person, index) => (
            <View key={index} style={styles.personCircle}>
              <Text style={styles.personInitials}>{person.initials}</Text>
            </View>
          ))}
        </View>
      </View>
    </ScrollView>

    {/* Görev Ekle Modal */}
    <Modal
      animationType="slide"
      transparent={true}
      visible={isGorevEkleModalVisible}
      onRequestClose={() => {
        toggleGorevEkleModal();
      }}>
      <View style={styles.modalContainer}>
        <View style={styles.modalContent}>
          <Text style={styles.modalTitle}>Görev Ekle</Text>

          {/* Görev Adı */}
          <TextInput
            style={styles.input}
            placeholder="Görev Adı"
            value={gorevAdi}
            onChangeText={(text) => setGorevAdi(text)}
          />

          {/* Görev Önceliği */}
          <DropDownPicker
            open={priorityOpen}
            value={priorityValue}
            items={priorityItems}
            setOpen={setPriorityOpen}
            setValue={setPriorityValue}
            setItems={setPriorityItems}
            containerStyle={[styles.input, { zIndex: 3 }]}
            theme="LIGHT"
            placeholder='Görev Önceliği Seçin'
          />

          {/* Görev Durumu */}
          <DropDownPicker
            open={statusOpen}
            value={selectedStatus}
            items={statusItems}
            setOpen={setStatusOpen}
            setValue={setStatusValue}
            setItems={setStatusItems}
            containerStyle={[styles.input, { zIndex: 2 }]}
            theme="LIGHT"
            placeholder='Görev Durumu Seçin'
          />

          {/* Görev Tarihi */}
          <TouchableOpacity onPress={showDatePicker}>
            <TextInput
              style={styles.input}
              placeholder="Görev Tarihi"
              value={gorevTarihi}
              editable={false}
            />
          </TouchableOpacity>
          <DateTimePickerModal
            isVisible={isDatePickerVisible}
            mode="date"
            onConfirm={handleConfirm}
            onCancel={hideDatePicker}
          />

          {/* Açıklama */}
          <TextInput
            style={[styles.input, { height: 100 }]}
            placeholder="Açıklama"
            multiline={true}
            numberOfLines={3}
            value={aciklama}
            onChangeText={(text) => setAciklama(text)}
          />

          {/* Kaydet ve Kapat butonları */}
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 20 }}>
            <TouchableOpacity onPress={gorevEkle}>
              <View style={styles.usttabButton1}>
                <Text style={styles.usttabButtonText1}>Kaydet</Text>
              </View>
            </TouchableOpacity>
            <TouchableOpacity onPress={toggleGorevEkleModal}>
              <View style={styles.usttabButton1}>
                <Text style={styles.usttabButtonText1}>Kapat</Text>
              </View>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>

    {/* Duyuru Ekle Modal */}
    <Modal
      animationType="slide"
      transparent={true}
      visible={isDuyuruEkleModalVisible}
      onRequestClose={() => {
        toggleDuyuruEkleModal();
      }}>
      <View style={styles.modalContainer}>
        <View style={styles.modalContent}>
          <Text style={styles.modalTitle}>Duyuru Ekle</Text>

         


  

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    padding: 16,
    justifyContent: 'center',
    alignItems:"center",
  },
  usttabButton1: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#00aff0',
  },
  usttabButtonText1: {
    fontWeight: 'bold',
    color: '#00aff0',
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  taskCard: {
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 16,
    width:'90%',
    marginBottom: 16,
    shadowColor: '#000',
    shadowColor: '#FF0000',
    elevation:5,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowRadius: 4,
    shadowOpacity: 0.2,
  },
  taskTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  taskDescription: {
    fontSize: 16,
    marginBottom: 8,
  },
  taskInfo: {
    fontSize: 14,
    color: '#555',
    marginBottom: 4,
  },
  assignedPeopleContainer: {
    flexDirection: 'row',
    marginTop: 8,
  },
  personCircle: {
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: '#00aff0',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 8,
  },
  personInitials: {
    color: '#fff',
    fontWeight: 'bold',
  },
  boldText: {
    fontWeight: 'bold',
  },
  usttab: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    backgroundColor: '#fff',
    paddingVertical: 10,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowRadius: 4,
    shadowOpacity: 0.2,
  },
  usttabButton: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#00aff0',
  },
  usttabButtonText: {
    fontWeight: 'bold',
    color: '#00aff0',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    width: '90%',
    padding: 20,
    backgroundColor: '#fff',
    borderRadius: 8,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    marginBottom: 10,
    padding: 8,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  modalSubtitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginTop: 10,
    marginBottom: 5,
  },
  personListContainer: {
    maxHeight: 150,
    marginBottom: 10,
  },
  gorevAtaItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 5,
  },
  selectedText: {
    color: 'green',
  },
  unselectedText: {
    color: 'red',
  },
  dropdown: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 15
}
});

export default AdminPage;