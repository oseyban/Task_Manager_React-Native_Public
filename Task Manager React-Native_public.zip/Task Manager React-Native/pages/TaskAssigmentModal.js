import React, { useState, useEffect } from 'react';
import { View, Text, Modal, StyleSheet, TouchableOpacity, FlatList, Alert } from 'react-native';
import { Checkbox } from 'react-native-paper';
import firebase from 'firebase/compat/app'; 
import 'firebase/compat/firestore';

const TaskAssignmentModal = ({ isVisible, onClose }) => {
  // State'lerin tanımlanması
  const [selectedTask, setSelectedTask] = useState(null);
  const [selectedPeople, setSelectedPeople] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [people, setPeople] = useState([]);

  // Firebase yapılandırması
  if (!firebase.apps.length) {
    firebase.initializeApp(firebaseConfig);
  }

  // Görevleri Firebase'den alma
  const fetchTasks = async () => {
    try {
      const tasksSnapshot = await firebase.firestore().collection('gorevler').get();
      const taskList = tasksSnapshot.docs.map(doc => doc.data().gorevAdi);
      setTasks(taskList);
    } catch (error) {
      console.error('Görevleri alma hatası:', error);
    }
  };

  // Kişileri Firebase'den alma
  const fetchPeople = async () => {
    try {
      const peopleSnapshot = await firebase.firestore().collection('users').get();
      const peopleList = peopleSnapshot.docs.map(doc => doc.data().adSoyad);
      setPeople(peopleList);
    } catch (error) {
      console.error('Kişileri alma hatası:', error);
    }
  };

  useEffect(() => {
    fetchTasks();
    fetchPeople();
  }, []);

  // Modal'ı kapatma işlemi
  const toggleModal = () => {
    setSelectedTask(null);
    setSelectedPeople([]);
    onClose();
  };

  // Görev atama işlemleri Firebase'e kaydedilir
  const assignTask = async () => {
    try {
      await clearAssignmentsForTaskInFirebase();
      await clearUnselectedPeopleAssignmentsInFirebase();
      await assignPeopleToTaskInFirebase();
      await assignTaskToPeopleInFirebase();

      Alert.alert(
        'Görev Atama',
        `${selectedTask} görevi, ${selectedPeople.join(', ')} kişilerine atandı.`,
        [{ text: 'Tamam' }],
        { cancelable: false }
      );

      toggleModal();
    } catch (error) {
      console.error('Görev atama hatası:', error);
    }
  };

  // Seçilen göreve atanan kişileri Firebase'e ekleme
  const assignPeopleToTaskInFirebase = async () => {
    if (selectedTask && selectedPeople.length > 0) {
      try {
        const tasksSnapshot = await firebase.firestore().collection('gorevler')
          .where('gorevAdi', '==', selectedTask)
          .get();
  
        if (!tasksSnapshot.empty) {
          const taskDoc = tasksSnapshot.docs[0];
          const taskRef = taskDoc.ref;
  
          await taskRef.collection('atananlar').add({
            adSoyad: selectedPeople,
          });
        } else {
          console.error('Belirtilen görev bulunamadı.');
        }
      } catch (error) {
        console.error('Atananları ekleme hatası:', error);
      }
    }
  };

  // Firebase'den belirli kişilere görev atama
  const assignTaskToPeopleInFirebase = async () => {
    if (selectedTask && selectedPeople.length > 0) {
      try {
        const peoplePromises = selectedPeople.map(async (person) => {
          try {
            const peopleSnapshot = await firebase.firestore().collection('users')
              .where('adSoyad', '==', person)
              .get();
  
            if (!peopleSnapshot.empty) {
              const personDoc = peopleSnapshot.docs[0];
              const personRef = personDoc.ref;
  
              await personRef.collection('gorevler').add({
                gorevAdi: selectedTask,
              });
            } else {
              console.error(`Belirtilen kişi (${person}) bulunamadı.`);
            }
          } catch (personError) {
            console.error(`Kişilere görev ekleme hatası: ${personError}`);
          }
        });
  
        await Promise.all(peoplePromises);
      } catch (error) {
        console.error('Kişilere görev ekleme hatası:', error);
      }
    }
  };

  // Seçilen görevin atamalarını Firebase'den temizleme
  const clearAssignmentsForTaskInFirebase = async () => {
    try {
      const taskName = selectedTask;
      const taskRef = await firebase.firestore().collection('gorevler').where('gorevAdi', '==', taskName).get();
  
      if (!taskRef.empty) {
        const taskDoc = taskRef.docs[0];
        const assignedPeopleSnapshot = await taskDoc.ref.collection('atananlar').get();
  
        for (const assignedPersonDoc of assignedPeopleSnapshot.docs) {
          await assignedPersonDoc.ref.delete();
        }
      } else {
        console.error('Belirtilen görev bulunamadı.');
      }
    } catch (error) {
      console.error('Görevin atamalarını temizleme hatası:', error);
    }
  };

  // Seçilmemiş kişilerin Firebase'den görev atamalarını temizleme
  const clearUnselectedPeopleAssignmentsInFirebase = async () => {
    try {
      const selectedPeopleSet = new Set(selectedPeople);
      const allPeopleSnapshot = await firebase.firestore().collection('users').get();
  
      for (const personDoc of allPeopleSnapshot.docs) {
        const personRef = personDoc.ref;
        const personName = personDoc.data().adSoyad;
  
        if (!selectedPeopleSet.has(personName)) {
          const assignedTasksSnapshot = await personRef.collection('gorevler').where('gorevAdi', '==', selectedTask).get();
  
          for (const assignedTaskDoc of assignedTasksSnapshot.docs) {
            await assignedTaskDoc.ref.delete();
          }
        }
      }
    } catch (error) {
      console.error('Seçili olmayan kişilerin atamalarını temizleme hatası:', error);
    }
  };

  return (
    <Modal
      transparent
      animationType="slide"
      visible={isVisible}
      onRequestClose={() => {
        console.log('Modal kapatıldı');
        toggleModal();
      }}
    >
      <View style={styles.modalContainer}>
        <View style={styles.contentContainer}>
          <Text style={styles.title}>Görev Seçimi</Text>

          {/* Görevlerin listelenmesi */}
          <FlatList
            data={tasks}
            keyExtractor={(item) => item
            }
            renderItem={({ item }) => (
              <TouchableOpacity onPress={() => setSelectedTask(item)}>
                <Text style={[styles.itemText, item === selectedTask && styles.selectedItem]}>{item}</Text>
              </TouchableOpacity>
            )}
          />

          <Text style={styles.title}>Kişi Seçimi</Text>

          {/* Kişilerin listelenmesi ve seçim yapılması */}
          <FlatList
            data={people}
            keyExtractor={(item) => item}
            renderItem={({ item }) => (
              <View style={styles.checkboxContainer}>
                <Checkbox
                  status={selectedPeople.includes(item) ? 'checked' : 'unchecked'}
                  onPress={() => {
                    const updatedPeople = selectedPeople.includes(item)
                      ? selectedPeople.filter((p) => p !== item)
                      : [...selectedPeople, item];
                    setSelectedPeople(updatedPeople);
                  }}
                />
                <Text style={styles.checkboxLabel}>{item}</Text>
              </View>
            )}
          />

          {/* Onayla ve Kapat butonları */}
          <View style={styles.buttonContainer}>
            <TouchableOpacity onPress={assignTask}>
              <View style={styles.button}>
                <Text style={styles.buttonText}>Onayla</Text>
              </View>
            </TouchableOpacity>
            <TouchableOpacity onPress={toggleModal}>
              <View style={styles.button}>
                <Text style={styles.buttonText}>Kapat</Text>
              </View>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  contentContainer: {
    width: '90%',
    height: '90%',
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 10,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  itemText: {
    marginBottom: 10,
    fontSize: 16,
    color: 'black',
  },
  selectedItem: {
    color: '#00aff0',
  },
  checkboxContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  checkboxLabel: {
    marginLeft: 10,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
  },
  button: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#00aff0',
  },
  buttonText: {
    fontWeight: 'bold',
    color: '#00aff0',
  },
});

export default TaskAssignmentModal;
