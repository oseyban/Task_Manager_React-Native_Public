import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { auth, firebase } from './firebase';

const SigninPage = () => {
  // State'lerin tanımlanması
  const [adSoyad, setAdSoyad] = useState('');
  const [eposta, setEposta] = useState('');
  const [sifre, setSifre] = useState('');
  const [telefon, setTelefon] = useState('');

  // Navigation hook'unun kullanılması
  const navigation = useNavigation();

  // Kullanıcı kaydı işlemini gerçekleştiren fonksiyon
  const handleSignup = async () => {
    try {
      // Firebase üzerinde kullanıcı oluşturma işlemi
      const userCredential = await auth.createUserWithEmailAndPassword(eposta, sifre);
      const user = userCredential.user;

      // Kullanıcı bilgilerini Firebase Firestore'a kaydetme
      const userDocRef = firebase.firestore().collection('users').doc(eposta);
      await userDocRef.set({
        adSoyad,
        eposta,
        telefon,
      });

      // Kullanıcıya e-posta doğrulama e-postası gönderme
      await sendVerificationEmail();

      // Anasayfaya yönlendirme
      navigation.navigate('HomePage');
    } catch (error) {
      console.error('Kayıt hatası:', error.message);
      alert(error.message);
    }
  };

  // E-posta doğrulama e-postası gönderme fonksiyonu
  const sendVerificationEmail = async () => {
    try {
      // Giriş yapan kullanıcının bilgilerini al
      const user = auth.currentUser;

      if (user) {
        // Kullanıcıya e-posta doğrulama e-postası gönder
        await user.sendEmailVerification();
        Alert.alert(
          'E-posta doğrulama',
          'Kaydınız başarıyla oluşturuldu. Lütfen e-posta adresinizi doğrulamak için e-postanızı kontrol edin.',
          [{ text: 'Tamam', onPress: () => console.log('OK Pressed') }]
        );
      } else {
        alert('Kullanıcı bulunamadı.');
      }
    } catch (error) {
      console.error('E-posta doğrulama e-postası gönderme hatası:', error.message);
      alert('E-posta doğrulama e-postası gönderme sırasında bir hata oluştu.');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Üyelik Oluştur</Text>

      {/* Ad Soyad Girişi */}
      <TextInput
        style={styles.input}
        placeholder="Ad Soyad"
        value={adSoyad}
        onChangeText={(text) => setAdSoyad(text)}
      />

      {/* E-posta Girişi */}
      <TextInput
        style={styles.input}
        placeholder="E-posta"
        keyboardType="email-address"
        value={eposta}
        onChangeText={(text) => setEposta(text)}
      />

      {/* Şifre Girişi */}
      <TextInput
        style={styles.input}
        placeholder="Şifre"
        secureTextEntry={true}
        value={sifre}
        onChangeText={(text) => setSifre(text)}
      />

      {/* Telefon Girişi */}
      <TextInput
        style={styles.input}
        placeholder="Telefon"
        keyboardType="phone-pad"
        value={telefon}
        onChangeText={(text) => setTelefon(text)}
      />

      {/* Kaydet ve Geri Dön Butonları */}
      <View style={styles.buttonContainer}>
        {/* Kaydet Butonu */}
        <TouchableOpacity onPress={handleSignup}>
          <View style={styles.button}>
            <Text style={styles.buttonText}>Kaydet</Text>
          </View>
        </TouchableOpacity>

        {/* Geri Dön Butonu */}
        <TouchableOpacity
          onPress={() => {
            navigation.navigate('HomePage');
          }}>
          <View style={styles.button}>
            <Text style={styles.buttonText}>Geri Dön</Text>
          </View>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
  },
  buttonText: {
    fontWeight: 'bold',
    fontSize: 15,
    color: 'white',
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  input: {
    height: 40,
    width: '80%',
    borderColor: 'gray',
    borderWidth: 0,
    borderBottomWidth: 1,
    borderBottomColor: 'gray',
    marginBottom: 12,
    paddingLeft: 8,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '80%',
    marginTop: 20,
  },
  button: {
    width: 100,
    height: 30,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 25,
    backgroundColor: '#00aff0',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 5,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
});

export default SigninPage;
